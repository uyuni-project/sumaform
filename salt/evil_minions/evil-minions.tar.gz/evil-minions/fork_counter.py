import os
import time

def child():
   print('\nA new child ',  os.getpid())
   time.sleep(500)
   os._exit(0)  

def parent():
   num = 1
   while num < 10500:
      newpid = os.fork()
      if newpid == 0:
         child()
      else:
         pids = (os.getpid(), newpid)
         print("parent: %d, child: %d\n" % pids)
      num = num + 2
      time.sleep(0.01)

parent()
